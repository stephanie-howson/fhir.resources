  README
  -------------
  TRACE FOR CLINICAL PROFILE:
  
  INFO     | Parsing profile "ClinicalProfile"
  DEBUG    | Created class "ClinicalProfile", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileLab", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileLabScalarDistribution", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileLabScalarDistributionDecile", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileLabScalarDistributionCorrelatedLabs", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileLabScalarDistributionCorrelatedLabsEntry", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileMedication", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileMedicationDosage", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileMedicationCorrelatedDiagnoses", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileMedicationCorrelatedDiagnosesEntry", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileMedicationCorrelatedMedications", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileMedicationCorrelatedMedicationsEntry", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileMedicationCorrelatedProcedures", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileMedicationCorrelatedProceduresEntry", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileMedicationCorrelatedPhenotypes", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileMedicationCorrelatedPhenotypesEntry", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileDiagnosis", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileProcedure", module clinicalprofile
  DEBUG    | Created class "ClinicalProfileHpo", module clinicalprofile
