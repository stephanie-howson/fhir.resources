# -*- coding: utf-8 -*-
#"""Top-level package for fhir.resources."""

#__author__ = """Md Nazrul Islam"""

#__email__ = 'email2nazrul@gmail.com'

#__version__ = "5.0.0b1"

#__fhir_version__ = "4.0.0-a53ec6ee1b"
