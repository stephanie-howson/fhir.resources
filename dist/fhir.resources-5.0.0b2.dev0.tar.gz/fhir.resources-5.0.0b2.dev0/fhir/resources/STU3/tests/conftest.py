# _*_ coding: utf-8 _*_
pytest_plugins = ['fhir.resources.STU3.tests.fixtures']
